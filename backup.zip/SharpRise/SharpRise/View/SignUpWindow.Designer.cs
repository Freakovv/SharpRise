﻿namespace SharpRise.ViewModels
{
    partial class SignUpWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUpWindow));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            btnMinimize = new Guna.UI2.WinForms.Guna2CircleButton();
            btnExit = new Guna.UI2.WinForms.Guna2CircleButton();
            border = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            dragMainWindow = new Guna.UI2.WinForms.Guna2DragControl(components);
            head = new Guna.UI2.WinForms.Guna2GradientPanel();
            layoutMainWindow = new TableLayoutPanel();
            btnGit = new Guna.UI2.WinForms.Guna2Button();
            ShadowPanel = new Guna.UI2.WinForms.Guna2ShadowPanel();
            panel1 = new Panel();
            btnSignUp = new Guna.UI2.WinForms.Guna2Button();
            textAgree = new Label();
            btnPolicy = new Guna.UI2.WinForms.Guna2Button();
            inputRepeatPassword = new Guna.UI2.WinForms.Guna2TextBox();
            inputPassword = new Guna.UI2.WinForms.Guna2TextBox();
            inputUsername = new Guna.UI2.WinForms.Guna2TextBox();
            inputEmail = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            pictureLogo = new Guna.UI2.WinForms.Guna2PictureBox();
            head.SuspendLayout();
            layoutMainWindow.SuspendLayout();
            ShadowPanel.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureLogo).BeginInit();
            SuspendLayout();
            // 
            // btnMinimize
            // 
            btnMinimize.Animated = true;
            btnMinimize.BackColor = Color.Transparent;
            btnMinimize.DisabledState.BorderColor = Color.DarkGray;
            btnMinimize.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMinimize.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMinimize.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMinimize.FillColor = Color.Transparent;
            btnMinimize.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnMinimize.ForeColor = Color.FromArgb(34, 35, 39);
            btnMinimize.Image = Properties.Resources.minimize;
            btnMinimize.Location = new Point(1216, 5);
            btnMinimize.Name = "btnMinimize";
            btnMinimize.ShadowDecoration.CustomizableEdges = customizableEdges1;
            btnMinimize.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            btnMinimize.Size = new Size(18, 18);
            btnMinimize.TabIndex = 2;
            btnMinimize.Click += btnMinimize_Click;
            // 
            // btnExit
            // 
            btnExit.Animated = true;
            btnExit.BackColor = Color.Transparent;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Transparent;
            btnExit.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnExit.ForeColor = Color.FromArgb(34, 35, 39);
            btnExit.Image = Properties.Resources.close;
            btnExit.Location = new Point(1240, 5);
            btnExit.Name = "btnExit";
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnExit.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            btnExit.Size = new Size(18, 18);
            btnExit.TabIndex = 1;
            btnExit.Click += btnExit_Click;
            // 
            // border
            // 
            border.BorderRadius = 10;
            border.ContainerControl = this;
            border.DockIndicatorTransparencyValue = 0.6D;
            border.TransparentWhileDrag = true;
            // 
            // dragMainWindow
            // 
            dragMainWindow.DockIndicatorTransparencyValue = 0.6D;
            dragMainWindow.TargetControl = head;
            dragMainWindow.TransparentWhileDrag = false;
            // 
            // head
            // 
            head.BackColor = Color.FromArgb(22, 23, 27);
            head.Controls.Add(btnMinimize);
            head.Controls.Add(btnExit);
            head.CustomizableEdges = customizableEdges3;
            head.Dock = DockStyle.Top;
            head.Location = new Point(0, 0);
            head.Name = "head";
            head.ShadowDecoration.CustomizableEdges = customizableEdges4;
            head.Size = new Size(1264, 25);
            head.TabIndex = 3;
            // 
            // layoutMainWindow
            // 
            layoutMainWindow.ColumnCount = 3;
            layoutMainWindow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            layoutMainWindow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60F));
            layoutMainWindow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20F));
            layoutMainWindow.Controls.Add(btnGit, 2, 2);
            layoutMainWindow.Controls.Add(ShadowPanel, 1, 1);
            layoutMainWindow.Controls.Add(label2, 0, 2);
            layoutMainWindow.Controls.Add(pictureLogo, 1, 0);
            layoutMainWindow.Location = new Point(0, 25);
            layoutMainWindow.Margin = new Padding(3, 2, 3, 2);
            layoutMainWindow.Name = "layoutMainWindow";
            layoutMainWindow.RowCount = 3;
            layoutMainWindow.RowStyles.Add(new RowStyle(SizeType.Absolute, 120F));
            layoutMainWindow.RowStyles.Add(new RowStyle(SizeType.Absolute, 300F));
            layoutMainWindow.RowStyles.Add(new RowStyle());
            layoutMainWindow.Size = new Size(1261, 654);
            layoutMainWindow.TabIndex = 4;
            // 
            // btnGit
            // 
            btnGit.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btnGit.BorderColor = Color.Gray;
            btnGit.BorderRadius = 10;
            btnGit.BorderThickness = 1;
            btnGit.CustomizableEdges = customizableEdges5;
            btnGit.DisabledState.BorderColor = Color.DarkGray;
            btnGit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnGit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnGit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnGit.FillColor = Color.FromArgb(39, 39, 41);
            btnGit.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnGit.ForeColor = Color.White;
            btnGit.HoverState.FillColor = Color.FromArgb(24, 24, 27);
            btnGit.Image = (Image)resources.GetObject("btnGit.Image");
            btnGit.ImageAlign = HorizontalAlignment.Right;
            btnGit.Location = new Point(1166, 616);
            btnGit.Margin = new Padding(0, 0, 10, 10);
            btnGit.Name = "btnGit";
            btnGit.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnGit.Size = new Size(85, 28);
            btnGit.TabIndex = 2;
            btnGit.Text = "GitHub ";
            btnGit.TextOffset = new Point(-10, -1);
            // 
            // ShadowPanel
            // 
            ShadowPanel.BackColor = Color.Transparent;
            ShadowPanel.Controls.Add(panel1);
            ShadowPanel.Dock = DockStyle.Fill;
            ShadowPanel.FillColor = Color.FromArgb(34, 35, 39);
            ShadowPanel.Location = new Point(255, 123);
            ShadowPanel.Name = "ShadowPanel";
            ShadowPanel.Radius = 5;
            ShadowPanel.ShadowColor = Color.Black;
            ShadowPanel.Size = new Size(750, 294);
            ShadowPanel.TabIndex = 3;
            // 
            // panel1
            // 
            panel1.Controls.Add(btnSignUp);
            panel1.Controls.Add(textAgree);
            panel1.Controls.Add(btnPolicy);
            panel1.Controls.Add(inputRepeatPassword);
            panel1.Controls.Add(inputPassword);
            panel1.Controls.Add(inputUsername);
            panel1.Controls.Add(inputEmail);
            panel1.Location = new Point(15, 15);
            panel1.Name = "panel1";
            panel1.Size = new Size(720, 269);
            panel1.TabIndex = 0;
            // 
            // btnSignUp
            // 
            btnSignUp.BorderRadius = 8;
            btnSignUp.CustomizableEdges = customizableEdges7;
            btnSignUp.DisabledState.BorderColor = Color.DarkGray;
            btnSignUp.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSignUp.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSignUp.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSignUp.FillColor = Color.FromArgb(186, 67, 43);
            btnSignUp.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnSignUp.ForeColor = Color.FromArgb(225, 228, 231);
            btnSignUp.HoverState.FillColor = Color.FromArgb(207, 75, 50);
            btnSignUp.Location = new Point(319, 233);
            btnSignUp.Margin = new Padding(1);
            btnSignUp.Name = "btnSignUp";
            btnSignUp.PressedColor = Color.White;
            btnSignUp.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnSignUp.Size = new Size(80, 30);
            btnSignUp.TabIndex = 15;
            btnSignUp.Text = "Запись";
            btnSignUp.Click += btnSignUp_ClickAsync;
            // 
            // textAgree
            // 
            textAgree.AutoSize = true;
            textAgree.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            textAgree.ForeColor = Color.FromArgb(201, 201, 201);
            textAgree.ImeMode = ImeMode.NoControl;
            textAgree.Location = new Point(68, 206);
            textAgree.Name = "textAgree";
            textAgree.Size = new Size(335, 18);
            textAgree.TabIndex = 13;
            textAgree.Text = "Создавая учетную запись, вы соглашаетесь с";
            // 
            // btnPolicy
            // 
            btnPolicy.BorderRadius = 10;
            btnPolicy.CustomizableEdges = customizableEdges9;
            btnPolicy.DisabledState.BorderColor = Color.DarkGray;
            btnPolicy.DisabledState.CustomBorderColor = Color.DarkGray;
            btnPolicy.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnPolicy.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnPolicy.FillColor = Color.FromArgb(34, 35, 39);
            btnPolicy.Font = new Font("Roboto", 11.25F, FontStyle.Underline, GraphicsUnit.Point);
            btnPolicy.ForeColor = Color.FromArgb(201, 201, 201);
            btnPolicy.HoverState.FillColor = Color.FromArgb(34, 35, 39);
            btnPolicy.HoverState.ForeColor = Color.FromArgb(103, 149, 222);
            btnPolicy.Location = new Point(397, 204);
            btnPolicy.Margin = new Padding(3, 2, 3, 2);
            btnPolicy.Name = "btnPolicy";
            btnPolicy.PressedDepth = 0;
            btnPolicy.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnPolicy.Size = new Size(273, 21);
            btnPolicy.TabIndex = 14;
            btnPolicy.Text = "политикой конфиденциальности";
            btnPolicy.TextOffset = new Point(-10, 0);
            // 
            // inputRepeatPassword
            // 
            inputRepeatPassword.Animated = true;
            inputRepeatPassword.BorderColor = Color.Empty;
            inputRepeatPassword.BorderRadius = 5;
            inputRepeatPassword.CustomizableEdges = customizableEdges11;
            inputRepeatPassword.DefaultText = "";
            inputRepeatPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputRepeatPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputRepeatPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputRepeatPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputRepeatPassword.FillColor = Color.FromArgb(20, 20, 20);
            inputRepeatPassword.FocusedState.BorderColor = Color.FromArgb(63, 63, 70);
            inputRepeatPassword.FocusedState.FillColor = Color.FromArgb(30, 30, 30);
            inputRepeatPassword.Font = new Font("Roboto", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            inputRepeatPassword.HoverState.FillColor = Color.Black;
            inputRepeatPassword.IconLeft = Properties.Resources._lock;
            inputRepeatPassword.Location = new Point(0, 154);
            inputRepeatPassword.Margin = new Padding(10, 3, 10, 3);
            inputRepeatPassword.MaxLength = 254;
            inputRepeatPassword.Name = "inputRepeatPassword";
            inputRepeatPassword.PlaceholderForeColor = Color.FromArgb(161, 161, 170);
            inputRepeatPassword.PlaceholderText = "* Подтверждение пароля";
            inputRepeatPassword.SelectedText = "";
            inputRepeatPassword.ShadowDecoration.CustomizableEdges = customizableEdges12;
            inputRepeatPassword.Size = new Size(719, 36);
            inputRepeatPassword.TabIndex = 3;
            inputRepeatPassword.UseSystemPasswordChar = true;
            // 
            // inputPassword
            // 
            inputPassword.Animated = true;
            inputPassword.BorderColor = Color.Empty;
            inputPassword.BorderRadius = 5;
            inputPassword.CustomizableEdges = customizableEdges13;
            inputPassword.DefaultText = "";
            inputPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputPassword.FillColor = Color.FromArgb(20, 20, 20);
            inputPassword.FocusedState.BorderColor = Color.FromArgb(63, 63, 70);
            inputPassword.FocusedState.FillColor = Color.FromArgb(30, 30, 30);
            inputPassword.Font = new Font("Roboto", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            inputPassword.HoverState.FillColor = Color.Black;
            inputPassword.IconLeft = Properties.Resources._lock;
            inputPassword.Location = new Point(0, 103);
            inputPassword.Margin = new Padding(10, 3, 10, 3);
            inputPassword.MaxLength = 254;
            inputPassword.Name = "inputPassword";
            inputPassword.PlaceholderForeColor = Color.FromArgb(161, 161, 170);
            inputPassword.PlaceholderText = "* Пароль";
            inputPassword.SelectedText = "";
            inputPassword.ShadowDecoration.CustomizableEdges = customizableEdges14;
            inputPassword.Size = new Size(719, 36);
            inputPassword.TabIndex = 2;
            inputPassword.UseSystemPasswordChar = true;
            // 
            // inputUsername
            // 
            inputUsername.Animated = true;
            inputUsername.BorderColor = Color.Empty;
            inputUsername.BorderRadius = 5;
            inputUsername.CustomizableEdges = customizableEdges15;
            inputUsername.DefaultText = "";
            inputUsername.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputUsername.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputUsername.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputUsername.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputUsername.FillColor = Color.FromArgb(20, 20, 20);
            inputUsername.FocusedState.BorderColor = Color.FromArgb(63, 63, 70);
            inputUsername.FocusedState.FillColor = Color.FromArgb(30, 30, 30);
            inputUsername.Font = new Font("Roboto", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            inputUsername.HoverState.FillColor = Color.Black;
            inputUsername.IconLeft = Properties.Resources.person;
            inputUsername.Location = new Point(0, 52);
            inputUsername.Margin = new Padding(10, 3, 10, 3);
            inputUsername.MaxLength = 30;
            inputUsername.Name = "inputUsername";
            inputUsername.PlaceholderForeColor = Color.FromArgb(161, 161, 170);
            inputUsername.PlaceholderText = "* Имя";
            inputUsername.SelectedText = "";
            inputUsername.ShadowDecoration.CustomizableEdges = customizableEdges16;
            inputUsername.Size = new Size(719, 36);
            inputUsername.TabIndex = 1;
            // 
            // inputEmail
            // 
            inputEmail.Animated = true;
            inputEmail.BorderColor = Color.Empty;
            inputEmail.BorderRadius = 5;
            inputEmail.CustomizableEdges = customizableEdges17;
            inputEmail.DefaultText = "";
            inputEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputEmail.FillColor = Color.FromArgb(20, 20, 20);
            inputEmail.FocusedState.BorderColor = Color.FromArgb(63, 63, 70);
            inputEmail.FocusedState.FillColor = Color.FromArgb(30, 30, 30);
            inputEmail.Font = new Font("Roboto", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            inputEmail.HoverState.FillColor = Color.Black;
            inputEmail.IconLeft = Properties.Resources.mail;
            inputEmail.Location = new Point(0, 0);
            inputEmail.Margin = new Padding(10, 3, 10, 3);
            inputEmail.MaxLength = 254;
            inputEmail.Name = "inputEmail";
            inputEmail.PlaceholderForeColor = Color.FromArgb(161, 161, 170);
            inputEmail.PlaceholderText = "* Email";
            inputEmail.SelectedText = "";
            inputEmail.ShadowDecoration.CustomizableEdges = customizableEdges18;
            inputEmail.Size = new Size(719, 36);
            inputEmail.TabIndex = 0;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label2.AutoSize = true;
            label2.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.ImeMode = ImeMode.NoControl;
            label2.Location = new Point(6, 630);
            label2.Margin = new Padding(6, 0, 3, 6);
            label2.Name = "label2";
            label2.Size = new Size(91, 18);
            label2.TabIndex = 4;
            label2.Text = "© SharpRise";
            // 
            // pictureLogo
            // 
            pictureLogo.BackColor = Color.Transparent;
            pictureLogo.BackgroundImageLayout = ImageLayout.None;
            pictureLogo.CustomizableEdges = customizableEdges19;
            pictureLogo.FillColor = Color.Transparent;
            pictureLogo.Image = Properties.Resources.logo;
            pictureLogo.ImageRotate = 0F;
            pictureLogo.InitialImage = null;
            pictureLogo.Location = new Point(255, 3);
            pictureLogo.Name = "pictureLogo";
            pictureLogo.ShadowDecoration.CustomizableEdges = customizableEdges20;
            pictureLogo.Size = new Size(750, 114);
            pictureLogo.SizeMode = PictureBoxSizeMode.Zoom;
            pictureLogo.TabIndex = 5;
            pictureLogo.TabStop = false;
            pictureLogo.UseTransparentBackground = true;
            // 
            // SignUpWindow
            // 
            AutoScaleDimensions = new SizeF(8F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(22, 23, 27);
            ClientSize = new Size(1264, 678);
            Controls.Add(head);
            Controls.Add(layoutMainWindow);
            DoubleBuffered = true;
            Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.None;
            Name = "SignUpWindow";
            Opacity = 0D;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SignUpWindow";
            head.ResumeLayout(false);
            layoutMainWindow.ResumeLayout(false);
            layoutMainWindow.PerformLayout();
            ShadowPanel.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureLogo).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2CircleButton btnMinimize;
        private Guna.UI2.WinForms.Guna2CircleButton btnExit;
        private Guna.UI2.WinForms.Guna2BorderlessForm border;
        private Guna.UI2.WinForms.Guna2DragControl dragMainWindow;
        private TableLayoutPanel layoutMainWindow;
        private Guna.UI2.WinForms.Guna2Button btnGit;
        private Guna.UI2.WinForms.Guna2ShadowPanel ShadowPanel;
        private Guna.UI2.WinForms.Guna2TextBox inputEmail;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2TextBox inputRepeatPassword;
        private Guna.UI2.WinForms.Guna2TextBox inputPassword;
        private Guna.UI2.WinForms.Guna2TextBox inputUsername;
        private Guna.UI2.WinForms.Guna2Button btnPolicy;
        private Label textAgree;
        private Guna.UI2.WinForms.Guna2Button btnSignUp;
        private Label label2;
        private Guna.UI2.WinForms.Guna2PictureBox pictureLogo;
        private Guna.UI2.WinForms.Guna2GradientPanel head;
    }
}