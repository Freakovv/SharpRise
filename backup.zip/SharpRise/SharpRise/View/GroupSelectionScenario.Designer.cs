﻿namespace SharpRise.ViewModels
{
    partial class GroupSelectionScenario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges45 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges46 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges47 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges48 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges49 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges50 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges51 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges52 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges53 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges54 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges55 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges58 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges59 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges56 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges57 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges63 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges64 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges60 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges61 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GroupSelectionScenario));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges62 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges65 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges66 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges67 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges68 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges69 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges70 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges76 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges77 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges71 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges72 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges73 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges74 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges75 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges81 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges82 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges78 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges79 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges80 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            border = new Guna.UI2.WinForms.Guna2BorderlessForm(components);
            head = new Guna.UI2.WinForms.Guna2GradientPanel();
            btnMinimize = new Guna.UI2.WinForms.Guna2CircleButton();
            btnExit = new Guna.UI2.WinForms.Guna2CircleButton();
            TabControl = new Guna.UI2.WinForms.Guna2TabControl();
            pgSelect = new TabPage();
            btnTeacher = new Label();
            btnIndependent = new Guna.UI2.WinForms.Guna2TileButton();
            btnGroups = new Guna.UI2.WinForms.Guna2TileButton();
            textPrompt = new Label();
            textChoice = new Label();
            pgInviteCode = new TabPage();
            btnCancel1 = new Guna.UI2.WinForms.Guna2Button();
            btnEnterStudent = new Guna.UI2.WinForms.Guna2Button();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            label5 = new Label();
            label6 = new Label();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            label2 = new Label();
            label3 = new Label();
            inputInviteCode1 = new Guna.UI2.WinForms.Guna2TextBox();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            btnChangeAccount = new Guna.UI2.WinForms.Guna2Button();
            textEmail = new Label();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            textUsername = new Label();
            label = new Label();
            label4 = new Label();
            teacherReg = new TabPage();
            btnCancel2 = new Guna.UI2.WinForms.Guna2Button();
            btnSkip = new Guna.UI2.WinForms.Guna2Button();
            btnEnterTeacher = new Guna.UI2.WinForms.Guna2Button();
            guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            label13 = new Label();
            btnGenerateCode = new Guna.UI2.WinForms.Guna2ImageButton();
            inputInviteCode2 = new Guna.UI2.WinForms.Guna2TextBox();
            label12 = new Label();
            label11 = new Label();
            label9 = new Label();
            label10 = new Label();
            inputGroupName = new Guna.UI2.WinForms.Guna2TextBox();
            guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            btnChangeAccount1 = new Guna.UI2.WinForms.Guna2Button();
            textEmail1 = new Label();
            guna2CirclePictureBox2 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            textUsername1 = new Label();
            label8 = new Label();
            dragMainWindow = new Guna.UI2.WinForms.Guna2DragControl(components);
            head.SuspendLayout();
            TabControl.SuspendLayout();
            pgSelect.SuspendLayout();
            pgInviteCode.SuspendLayout();
            guna2Panel2.SuspendLayout();
            guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            teacherReg.SuspendLayout();
            guna2Panel4.SuspendLayout();
            guna2Panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox2).BeginInit();
            SuspendLayout();
            // 
            // border
            // 
            border.BorderRadius = 10;
            border.ContainerControl = this;
            border.DockIndicatorTransparencyValue = 0.6D;
            border.TransparentWhileDrag = true;
            // 
            // head
            // 
            head.BackColor = Color.FromArgb(22, 23, 27);
            head.Controls.Add(btnMinimize);
            head.Controls.Add(btnExit);
            head.CustomizableEdges = customizableEdges44;
            head.Dock = DockStyle.Top;
            head.Location = new Point(0, 0);
            head.Name = "head";
            head.ShadowDecoration.CustomizableEdges = customizableEdges45;
            head.Size = new Size(1264, 30);
            head.TabIndex = 4;
            // 
            // btnMinimize
            // 
            btnMinimize.Animated = true;
            btnMinimize.BackColor = Color.Transparent;
            btnMinimize.DisabledState.BorderColor = Color.DarkGray;
            btnMinimize.DisabledState.CustomBorderColor = Color.DarkGray;
            btnMinimize.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnMinimize.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnMinimize.FillColor = Color.Transparent;
            btnMinimize.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnMinimize.ForeColor = Color.FromArgb(34, 35, 39);
            btnMinimize.Image = Properties.Resources.minimize;
            btnMinimize.Location = new Point(1216, 6);
            btnMinimize.Name = "btnMinimize";
            btnMinimize.ShadowDecoration.CustomizableEdges = customizableEdges42;
            btnMinimize.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            btnMinimize.Size = new Size(18, 18);
            btnMinimize.TabIndex = 2;
            btnMinimize.Click += btnMinimize_Click;
            // 
            // btnExit
            // 
            btnExit.Animated = true;
            btnExit.BackColor = Color.Transparent;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Transparent;
            btnExit.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnExit.ForeColor = Color.FromArgb(34, 35, 39);
            btnExit.Image = Properties.Resources.close;
            btnExit.Location = new Point(1239, 6);
            btnExit.Name = "btnExit";
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges43;
            btnExit.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            btnExit.Size = new Size(18, 18);
            btnExit.TabIndex = 1;
            btnExit.Click += btnExit_Click;
            // 
            // TabControl
            // 
            TabControl.Controls.Add(pgSelect);
            TabControl.Controls.Add(pgInviteCode);
            TabControl.Controls.Add(teacherReg);
            TabControl.ItemSize = new Size(180, 40);
            TabControl.Location = new Point(12, 31);
            TabControl.Name = "TabControl";
            TabControl.SelectedIndex = 0;
            TabControl.Size = new Size(1240, 635);
            TabControl.TabButtonHoverState.BorderColor = Color.Empty;
            TabControl.TabButtonHoverState.FillColor = Color.FromArgb(40, 52, 70);
            TabControl.TabButtonHoverState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            TabControl.TabButtonHoverState.ForeColor = Color.White;
            TabControl.TabButtonHoverState.InnerColor = Color.FromArgb(40, 52, 70);
            TabControl.TabButtonIdleState.BorderColor = Color.Empty;
            TabControl.TabButtonIdleState.FillColor = Color.FromArgb(33, 42, 57);
            TabControl.TabButtonIdleState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            TabControl.TabButtonIdleState.ForeColor = Color.FromArgb(156, 160, 167);
            TabControl.TabButtonIdleState.InnerColor = Color.FromArgb(33, 42, 57);
            TabControl.TabButtonSelectedState.BorderColor = Color.Empty;
            TabControl.TabButtonSelectedState.FillColor = Color.FromArgb(29, 37, 49);
            TabControl.TabButtonSelectedState.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Regular, GraphicsUnit.Point);
            TabControl.TabButtonSelectedState.ForeColor = Color.White;
            TabControl.TabButtonSelectedState.InnerColor = Color.FromArgb(76, 132, 255);
            TabControl.TabButtonSize = new Size(180, 40);
            TabControl.TabIndex = 5;
            TabControl.TabMenuBackColor = Color.FromArgb(33, 42, 57);
            TabControl.TabMenuOrientation = Guna.UI2.WinForms.TabMenuOrientation.HorizontalTop;
            // 
            // pgSelect
            // 
            pgSelect.BackColor = Color.FromArgb(22, 23, 27);
            pgSelect.Controls.Add(btnTeacher);
            pgSelect.Controls.Add(btnIndependent);
            pgSelect.Controls.Add(btnGroups);
            pgSelect.Controls.Add(textPrompt);
            pgSelect.Controls.Add(textChoice);
            pgSelect.Location = new Point(4, 44);
            pgSelect.Name = "pgSelect";
            pgSelect.Padding = new Padding(3);
            pgSelect.Size = new Size(1232, 587);
            pgSelect.TabIndex = 0;
            pgSelect.Text = "pgSelect";
            // 
            // btnTeacher
            // 
            btnTeacher.AutoSize = true;
            btnTeacher.Cursor = Cursors.Hand;
            btnTeacher.Font = new Font("Roboto", 9F, FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point);
            btnTeacher.ForeColor = Color.Gray;
            btnTeacher.Location = new Point(525, 489);
            btnTeacher.Name = "btnTeacher";
            btnTeacher.Size = new Size(228, 14);
            btnTeacher.TabIndex = 7;
            btnTeacher.Text = "Если вы преподаватель нажмите здесь";
            btnTeacher.TextAlign = ContentAlignment.MiddleCenter;
            btnTeacher.Click += btnTeacher_Click;
            // 
            // btnIndependent
            // 
            btnIndependent.Animated = true;
            btnIndependent.CustomizableEdges = customizableEdges46;
            btnIndependent.DisabledState.BorderColor = Color.DarkGray;
            btnIndependent.DisabledState.CustomBorderColor = Color.DarkGray;
            btnIndependent.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnIndependent.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnIndependent.FillColor = Color.FromArgb(186, 67, 43);
            btnIndependent.Font = new Font("Roboto SemiBold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnIndependent.ForeColor = Color.White;
            btnIndependent.Image = Properties.Resources.groups;
            btnIndependent.ImageOffset = new Point(0, 50);
            btnIndependent.ImageSize = new Size(150, 150);
            btnIndependent.Location = new Point(640, 158);
            btnIndependent.Name = "btnIndependent";
            btnIndependent.PressedDepth = 0;
            btnIndependent.ShadowDecoration.CustomizableEdges = customizableEdges47;
            btnIndependent.Size = new Size(250, 250);
            btnIndependent.TabIndex = 5;
            btnIndependent.Text = "Самостоятельно";
            btnIndependent.TextOffset = new Point(0, 30);
            btnIndependent.Click += btnIndependent_Click;
            // 
            // btnGroups
            // 
            btnGroups.Animated = true;
            btnGroups.CustomizableEdges = customizableEdges48;
            btnGroups.DisabledState.BorderColor = Color.DarkGray;
            btnGroups.DisabledState.CustomBorderColor = Color.DarkGray;
            btnGroups.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnGroups.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnGroups.FillColor = Color.FromArgb(186, 67, 43);
            btnGroups.Font = new Font("Roboto SemiBold", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnGroups.ForeColor = Color.White;
            btnGroups.Image = Properties.Resources.person;
            btnGroups.ImageOffset = new Point(0, 50);
            btnGroups.ImageSize = new Size(150, 150);
            btnGroups.Location = new Point(362, 158);
            btnGroups.Name = "btnGroups";
            btnGroups.PressedDepth = 0;
            btnGroups.ShadowDecoration.CustomizableEdges = customizableEdges49;
            btnGroups.Size = new Size(250, 250);
            btnGroups.TabIndex = 3;
            btnGroups.Text = "Группы";
            btnGroups.TextOffset = new Point(0, 30);
            btnGroups.Click += btnGroups_Click;
            // 
            // textPrompt
            // 
            textPrompt.AutoSize = true;
            textPrompt.Font = new Font("Roboto", 9F, FontStyle.Italic, GraphicsUnit.Point);
            textPrompt.ForeColor = Color.Gray;
            textPrompt.Location = new Point(450, 100);
            textPrompt.Name = "textPrompt";
            textPrompt.Size = new Size(329, 14);
            textPrompt.TabIndex = 1;
            textPrompt.Text = "вы сможете сменить тип в приложении в любой момент";
            textPrompt.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // textChoice
            // 
            textChoice.AutoSize = true;
            textChoice.Font = new Font("Roboto", 18F, FontStyle.Regular, GraphicsUnit.Point);
            textChoice.ForeColor = Color.White;
            textChoice.Location = new Point(475, 71);
            textChoice.Name = "textChoice";
            textChoice.Size = new Size(281, 29);
            textChoice.TabIndex = 0;
            textChoice.Text = "Выберите тип обучения";
            textChoice.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pgInviteCode
            // 
            pgInviteCode.BackColor = Color.FromArgb(22, 23, 27);
            pgInviteCode.Controls.Add(btnCancel1);
            pgInviteCode.Controls.Add(btnEnterStudent);
            pgInviteCode.Controls.Add(guna2Button1);
            pgInviteCode.Controls.Add(label5);
            pgInviteCode.Controls.Add(label6);
            pgInviteCode.Controls.Add(guna2Panel2);
            pgInviteCode.Controls.Add(guna2Panel1);
            pgInviteCode.Controls.Add(label4);
            pgInviteCode.Location = new Point(4, 44);
            pgInviteCode.Name = "pgInviteCode";
            pgInviteCode.Padding = new Padding(3);
            pgInviteCode.Size = new Size(1232, 587);
            pgInviteCode.TabIndex = 1;
            pgInviteCode.Text = "pgInviteCode";
            // 
            // btnCancel1
            // 
            btnCancel1.BorderRadius = 8;
            btnCancel1.CustomizableEdges = customizableEdges50;
            btnCancel1.DisabledState.BorderColor = Color.DarkGray;
            btnCancel1.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel1.FillColor = Color.FromArgb(186, 67, 43);
            btnCancel1.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnCancel1.ForeColor = Color.FromArgb(225, 228, 231);
            btnCancel1.HoverState.FillColor = Color.FromArgb(207, 75, 50);
            btnCancel1.Location = new Point(963, 553);
            btnCancel1.Margin = new Padding(1);
            btnCancel1.Name = "btnCancel1";
            btnCancel1.PressedColor = Color.White;
            btnCancel1.ShadowDecoration.CustomizableEdges = customizableEdges51;
            btnCancel1.Size = new Size(127, 30);
            btnCancel1.TabIndex = 20;
            btnCancel1.Text = "Отмена";
            btnCancel1.Click += btnCancel_Click;
            // 
            // btnEnterStudent
            // 
            btnEnterStudent.BorderRadius = 8;
            btnEnterStudent.CustomizableEdges = customizableEdges52;
            btnEnterStudent.DisabledState.BorderColor = Color.DarkGray;
            btnEnterStudent.DisabledState.CustomBorderColor = Color.DarkGray;
            btnEnterStudent.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnEnterStudent.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnEnterStudent.FillColor = Color.FromArgb(186, 67, 43);
            btnEnterStudent.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnEnterStudent.ForeColor = Color.FromArgb(225, 228, 231);
            btnEnterStudent.HoverState.FillColor = Color.FromArgb(207, 75, 50);
            btnEnterStudent.Location = new Point(1099, 553);
            btnEnterStudent.Margin = new Padding(1);
            btnEnterStudent.Name = "btnEnterStudent";
            btnEnterStudent.PressedColor = Color.White;
            btnEnterStudent.ShadowDecoration.CustomizableEdges = customizableEdges53;
            btnEnterStudent.Size = new Size(127, 30);
            btnEnterStudent.TabIndex = 19;
            btnEnterStudent.Text = "Продолжить";
            // 
            // guna2Button1
            // 
            guna2Button1.BorderRadius = 8;
            guna2Button1.CustomizableEdges = customizableEdges54;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.FillColor = Color.FromArgb(186, 67, 43);
            guna2Button1.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            guna2Button1.ForeColor = Color.FromArgb(225, 228, 231);
            guna2Button1.HoverState.FillColor = Color.FromArgb(207, 75, 50);
            guna2Button1.Location = new Point(1099, 592);
            guna2Button1.Margin = new Padding(1);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.PressedColor = Color.White;
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges55;
            guna2Button1.Size = new Size(127, 30);
            guna2Button1.TabIndex = 17;
            guna2Button1.Text = "Продолжить";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(16, 456);
            label5.Name = "label5";
            label5.Size = new Size(303, 18);
            label5.TabIndex = 6;
            label5.Text = "• Используйте аккаунт с правом доступа.";
            label5.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(16, 493);
            label6.Name = "label6";
            label6.Size = new Size(528, 18);
            label6.TabIndex = 5;
            label6.Text = "• Введите код курса, состоящий из 8 букв и цифр и одного спецсимвола.";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // guna2Panel2
            // 
            guna2Panel2.BorderColor = Color.Gray;
            guna2Panel2.BorderRadius = 10;
            guna2Panel2.BorderThickness = 1;
            guna2Panel2.Controls.Add(label2);
            guna2Panel2.Controls.Add(label3);
            guna2Panel2.Controls.Add(inputInviteCode1);
            guna2Panel2.CustomizableEdges = customizableEdges58;
            guna2Panel2.Location = new Point(6, 210);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges59;
            guna2Panel2.Size = new Size(1220, 178);
            guna2Panel2.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Roboto", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(17, 28);
            label2.Name = "label2";
            label2.Size = new Size(142, 29);
            label2.TabIndex = 5;
            label2.Text = "Код группы";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Roboto Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(20, 57);
            label3.Name = "label3";
            label3.Size = new Size(332, 14);
            label3.TabIndex = 3;
            label3.Text = "Введите код группы (его можно узнать у преподавателя).";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // inputInviteCode1
            // 
            inputInviteCode1.Animated = true;
            inputInviteCode1.BorderColor = Color.Empty;
            inputInviteCode1.BorderRadius = 5;
            inputInviteCode1.CharacterCasing = CharacterCasing.Upper;
            inputInviteCode1.CustomizableEdges = customizableEdges56;
            inputInviteCode1.DefaultText = "";
            inputInviteCode1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputInviteCode1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputInviteCode1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputInviteCode1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputInviteCode1.FillColor = Color.FromArgb(20, 20, 20);
            inputInviteCode1.FocusedState.BorderColor = Color.FromArgb(63, 63, 70);
            inputInviteCode1.FocusedState.FillColor = Color.FromArgb(30, 30, 30);
            inputInviteCode1.Font = new Font("Roboto", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            inputInviteCode1.HoverState.FillColor = Color.Black;
            inputInviteCode1.IconLeft = Properties.Resources.key;
            inputInviteCode1.Location = new Point(21, 102);
            inputInviteCode1.Margin = new Padding(10, 3, 10, 3);
            inputInviteCode1.MaxLength = 9;
            inputInviteCode1.Name = "inputInviteCode1";
            inputInviteCode1.PlaceholderForeColor = Color.FromArgb(161, 161, 170);
            inputInviteCode1.PlaceholderText = "QWER-1234";
            inputInviteCode1.SelectedText = "";
            inputInviteCode1.ShadowDecoration.CustomizableEdges = customizableEdges57;
            inputInviteCode1.Size = new Size(186, 41);
            inputInviteCode1.TabIndex = 2;
            inputInviteCode1.TextAlign = HorizontalAlignment.Center;
            inputInviteCode1.TextChanged += InputInviteCode_TextChanged;
            // 
            // guna2Panel1
            // 
            guna2Panel1.BorderColor = Color.Gray;
            guna2Panel1.BorderRadius = 10;
            guna2Panel1.BorderThickness = 1;
            guna2Panel1.Controls.Add(btnChangeAccount);
            guna2Panel1.Controls.Add(textEmail);
            guna2Panel1.Controls.Add(guna2CirclePictureBox1);
            guna2Panel1.Controls.Add(textUsername);
            guna2Panel1.Controls.Add(label);
            guna2Panel1.CustomizableEdges = customizableEdges63;
            guna2Panel1.Location = new Point(6, 11);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges64;
            guna2Panel1.Size = new Size(1220, 193);
            guna2Panel1.TabIndex = 3;
            // 
            // btnChangeAccount
            // 
            btnChangeAccount.BorderRadius = 8;
            btnChangeAccount.CustomizableEdges = customizableEdges60;
            btnChangeAccount.DisabledState.BorderColor = Color.DarkGray;
            btnChangeAccount.DisabledState.CustomBorderColor = Color.DarkGray;
            btnChangeAccount.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnChangeAccount.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnChangeAccount.FillColor = Color.FromArgb(186, 67, 43);
            btnChangeAccount.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnChangeAccount.ForeColor = Color.FromArgb(225, 228, 231);
            btnChangeAccount.HoverState.FillColor = Color.FromArgb(207, 75, 50);
            btnChangeAccount.Location = new Point(142, 124);
            btnChangeAccount.Margin = new Padding(1);
            btnChangeAccount.Name = "btnChangeAccount";
            btnChangeAccount.PressedColor = Color.White;
            btnChangeAccount.ShadowDecoration.CustomizableEdges = customizableEdges61;
            btnChangeAccount.Size = new Size(149, 30);
            btnChangeAccount.TabIndex = 16;
            btnChangeAccount.Text = "Сменить аккаунт";
            btnChangeAccount.Click += btnChangeAccount_Click;
            // 
            // textEmail
            // 
            textEmail.AutoSize = true;
            textEmail.Font = new Font("Roboto", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            textEmail.ForeColor = Color.Gray;
            textEmail.Location = new Point(141, 96);
            textEmail.Name = "textEmail";
            textEmail.Size = new Size(38, 15);
            textEmail.TabIndex = 5;
            textEmail.Text = "Email";
            textEmail.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.BackColor = Color.Transparent;
            guna2CirclePictureBox1.Image = (Image)resources.GetObject("guna2CirclePictureBox1.Image");
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.InitialImage = null;
            guna2CirclePictureBox1.Location = new Point(19, 54);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges62;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(100, 100);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            guna2CirclePictureBox1.TabIndex = 3;
            guna2CirclePictureBox1.TabStop = false;
            guna2CirclePictureBox1.UseTransparentBackground = true;
            // 
            // textUsername
            // 
            textUsername.AutoSize = true;
            textUsername.Font = new Font("Roboto", 18F, FontStyle.Regular, GraphicsUnit.Point);
            textUsername.ForeColor = Color.White;
            textUsername.Location = new Point(138, 66);
            textUsername.Name = "textUsername";
            textUsername.Size = new Size(122, 29);
            textUsername.TabIndex = 4;
            textUsername.Text = "Username";
            // 
            // label
            // 
            label.AutoSize = true;
            label.Font = new Font("Roboto", 9F, FontStyle.Italic, GraphicsUnit.Point);
            label.ForeColor = Color.Gray;
            label.Location = new Point(10, 9);
            label.Name = "label";
            label.Size = new Size(119, 14);
            label.TabIndex = 2;
            label.Text = "Вы вошли в аккаунт";
            label.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Roboto", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(16, 414);
            label4.Name = "label4";
            label4.Size = new Size(418, 23);
            label4.TabIndex = 2;
            label4.Text = "Как выполнить вход с помощью кода группы";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // teacherReg
            // 
            teacherReg.BackColor = Color.FromArgb(22, 23, 27);
            teacherReg.Controls.Add(btnCancel2);
            teacherReg.Controls.Add(btnSkip);
            teacherReg.Controls.Add(btnEnterTeacher);
            teacherReg.Controls.Add(guna2Panel4);
            teacherReg.Controls.Add(guna2Panel3);
            teacherReg.Location = new Point(4, 44);
            teacherReg.Name = "teacherReg";
            teacherReg.Padding = new Padding(3);
            teacherReg.Size = new Size(1232, 587);
            teacherReg.TabIndex = 2;
            teacherReg.Text = "teacherReg";
            // 
            // btnCancel2
            // 
            btnCancel2.BorderRadius = 8;
            btnCancel2.CustomizableEdges = customizableEdges65;
            btnCancel2.DisabledState.BorderColor = Color.DarkGray;
            btnCancel2.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel2.FillColor = Color.FromArgb(186, 67, 43);
            btnCancel2.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnCancel2.ForeColor = Color.FromArgb(225, 228, 231);
            btnCancel2.HoverState.FillColor = Color.FromArgb(207, 75, 50);
            btnCancel2.Location = new Point(843, 553);
            btnCancel2.Margin = new Padding(1);
            btnCancel2.Name = "btnCancel2";
            btnCancel2.PressedColor = Color.White;
            btnCancel2.ShadowDecoration.CustomizableEdges = customizableEdges66;
            btnCancel2.Size = new Size(127, 30);
            btnCancel2.TabIndex = 23;
            btnCancel2.Text = "Отмена";
            btnCancel2.Click += btnCancel_Click;
            // 
            // btnSkip
            // 
            btnSkip.BorderRadius = 8;
            btnSkip.CustomizableEdges = customizableEdges67;
            btnSkip.DisabledState.BorderColor = Color.DarkGray;
            btnSkip.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSkip.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSkip.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSkip.FillColor = Color.FromArgb(186, 67, 43);
            btnSkip.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnSkip.ForeColor = Color.FromArgb(225, 228, 231);
            btnSkip.HoverState.FillColor = Color.FromArgb(207, 75, 50);
            btnSkip.Location = new Point(972, 553);
            btnSkip.Margin = new Padding(1);
            btnSkip.Name = "btnSkip";
            btnSkip.PressedColor = Color.White;
            btnSkip.ShadowDecoration.CustomizableEdges = customizableEdges68;
            btnSkip.Size = new Size(127, 30);
            btnSkip.TabIndex = 22;
            btnSkip.Text = "Пропустить";
            // 
            // btnEnterTeacher
            // 
            btnEnterTeacher.BorderRadius = 8;
            btnEnterTeacher.CustomizableEdges = customizableEdges69;
            btnEnterTeacher.DisabledState.BorderColor = Color.DarkGray;
            btnEnterTeacher.DisabledState.CustomBorderColor = Color.DarkGray;
            btnEnterTeacher.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnEnterTeacher.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnEnterTeacher.FillColor = Color.FromArgb(186, 67, 43);
            btnEnterTeacher.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnEnterTeacher.ForeColor = Color.FromArgb(225, 228, 231);
            btnEnterTeacher.HoverState.FillColor = Color.FromArgb(207, 75, 50);
            btnEnterTeacher.Location = new Point(1101, 553);
            btnEnterTeacher.Margin = new Padding(1);
            btnEnterTeacher.Name = "btnEnterTeacher";
            btnEnterTeacher.PressedColor = Color.White;
            btnEnterTeacher.ShadowDecoration.CustomizableEdges = customizableEdges70;
            btnEnterTeacher.Size = new Size(127, 30);
            btnEnterTeacher.TabIndex = 21;
            btnEnterTeacher.Text = "Продолжить";
            btnEnterTeacher.Click += btnEnter2_Click;
            // 
            // guna2Panel4
            // 
            guna2Panel4.BorderColor = Color.Gray;
            guna2Panel4.BorderRadius = 10;
            guna2Panel4.BorderThickness = 1;
            guna2Panel4.Controls.Add(label13);
            guna2Panel4.Controls.Add(btnGenerateCode);
            guna2Panel4.Controls.Add(inputInviteCode2);
            guna2Panel4.Controls.Add(label12);
            guna2Panel4.Controls.Add(label11);
            guna2Panel4.Controls.Add(label9);
            guna2Panel4.Controls.Add(label10);
            guna2Panel4.Controls.Add(inputGroupName);
            guna2Panel4.CustomizableEdges = customizableEdges76;
            guna2Panel4.Location = new Point(6, 210);
            guna2Panel4.Name = "guna2Panel4";
            guna2Panel4.ShadowDecoration.CustomizableEdges = customizableEdges77;
            guna2Panel4.Size = new Size(1220, 339);
            guna2Panel4.TabIndex = 5;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Roboto", 9F, FontStyle.Italic, GraphicsUnit.Point);
            label13.ForeColor = Color.Gray;
            label13.Location = new Point(19, 255);
            label13.Name = "label13";
            label13.Size = new Size(272, 14);
            label13.TabIndex = 12;
            label13.Text = "Оставьте поле пустым чтобы задать код позже";
            label13.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnGenerateCode
            // 
            btnGenerateCode.CheckedState.ImageSize = new Size(64, 64);
            btnGenerateCode.HoverState.ImageSize = new Size(25, 25);
            btnGenerateCode.Image = (Image)resources.GetObject("btnGenerateCode.Image");
            btnGenerateCode.ImageOffset = new Point(0, 0);
            btnGenerateCode.ImageRotate = 0F;
            btnGenerateCode.ImageSize = new Size(25, 25);
            btnGenerateCode.Location = new Point(214, 211);
            btnGenerateCode.Name = "btnGenerateCode";
            btnGenerateCode.PressedState.ImageSize = new Size(64, 64);
            btnGenerateCode.ShadowDecoration.CustomizableEdges = customizableEdges71;
            btnGenerateCode.Size = new Size(30, 30);
            btnGenerateCode.TabIndex = 11;
            btnGenerateCode.Click += BtnGenerateCode_Click;
            // 
            // inputInviteCode2
            // 
            inputInviteCode2.Animated = true;
            inputInviteCode2.BorderColor = Color.Empty;
            inputInviteCode2.BorderRadius = 5;
            inputInviteCode2.CharacterCasing = CharacterCasing.Upper;
            inputInviteCode2.CustomizableEdges = customizableEdges72;
            inputInviteCode2.DefaultText = "";
            inputInviteCode2.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputInviteCode2.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputInviteCode2.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputInviteCode2.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputInviteCode2.FillColor = Color.FromArgb(20, 20, 20);
            inputInviteCode2.FocusedState.BorderColor = Color.FromArgb(63, 63, 70);
            inputInviteCode2.FocusedState.FillColor = Color.FromArgb(30, 30, 30);
            inputInviteCode2.Font = new Font("Roboto", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            inputInviteCode2.HoverState.FillColor = Color.Black;
            inputInviteCode2.IconLeft = Properties.Resources.key;
            inputInviteCode2.Location = new Point(21, 206);
            inputInviteCode2.Margin = new Padding(10, 3, 10, 3);
            inputInviteCode2.MaxLength = 9;
            inputInviteCode2.Name = "inputInviteCode2";
            inputInviteCode2.PlaceholderForeColor = Color.FromArgb(161, 161, 170);
            inputInviteCode2.PlaceholderText = "QWER-1234";
            inputInviteCode2.SelectedText = "";
            inputInviteCode2.ShadowDecoration.CustomizableEdges = customizableEdges73;
            inputInviteCode2.Size = new Size(186, 41);
            inputInviteCode2.TabIndex = 10;
            inputInviteCode2.TextAlign = HorizontalAlignment.Center;
            inputInviteCode2.TextChanged += InputInviteCode_TextChanged;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Roboto Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = Color.White;
            label12.Location = new Point(19, 180);
            label12.Name = "label12";
            label12.Size = new Size(73, 14);
            label12.TabIndex = 9;
            label12.Text = "Код группы";
            label12.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Roboto Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = Color.White;
            label11.Location = new Point(19, 83);
            label11.Name = "label11";
            label11.Size = new Size(178, 14);
            label11.TabIndex = 8;
            label11.Text = "Название курса (обязательно)";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Roboto", 18F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(18, 20);
            label9.Name = "label9";
            label9.Size = new Size(210, 29);
            label9.TabIndex = 7;
            label9.Text = "Создание группы";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Roboto Light", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.White;
            label10.Location = new Point(21, 49);
            label10.Name = "label10";
            label10.Size = new Size(321, 14);
            label10.TabIndex = 6;
            label10.Text = "Создайте свою первую группу и пригласите студентов.";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // inputGroupName
            // 
            inputGroupName.Animated = true;
            inputGroupName.BorderColor = Color.Empty;
            inputGroupName.BorderRadius = 5;
            inputGroupName.CharacterCasing = CharacterCasing.Upper;
            inputGroupName.CustomizableEdges = customizableEdges74;
            inputGroupName.DefaultText = "";
            inputGroupName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            inputGroupName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            inputGroupName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            inputGroupName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            inputGroupName.FillColor = Color.FromArgb(20, 20, 20);
            inputGroupName.FocusedState.BorderColor = Color.FromArgb(63, 63, 70);
            inputGroupName.FocusedState.FillColor = Color.FromArgb(30, 30, 30);
            inputGroupName.Font = new Font("Roboto", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            inputGroupName.HoverState.FillColor = Color.Black;
            inputGroupName.IconLeft = (Image)resources.GetObject("inputGroupName.IconLeft");
            inputGroupName.Location = new Point(19, 109);
            inputGroupName.Margin = new Padding(10, 3, 10, 3);
            inputGroupName.MaxLength = 20;
            inputGroupName.Name = "inputGroupName";
            inputGroupName.PlaceholderForeColor = Color.FromArgb(161, 161, 170);
            inputGroupName.PlaceholderText = "КПиЯП Т-295";
            inputGroupName.SelectedText = "";
            inputGroupName.ShadowDecoration.CustomizableEdges = customizableEdges75;
            inputGroupName.Size = new Size(186, 41);
            inputGroupName.TabIndex = 2;
            inputGroupName.TextAlign = HorizontalAlignment.Center;
            // 
            // guna2Panel3
            // 
            guna2Panel3.BorderColor = Color.Gray;
            guna2Panel3.BorderRadius = 10;
            guna2Panel3.BorderThickness = 1;
            guna2Panel3.Controls.Add(btnChangeAccount1);
            guna2Panel3.Controls.Add(textEmail1);
            guna2Panel3.Controls.Add(guna2CirclePictureBox2);
            guna2Panel3.Controls.Add(textUsername1);
            guna2Panel3.Controls.Add(label8);
            guna2Panel3.CustomizableEdges = customizableEdges81;
            guna2Panel3.Location = new Point(6, 11);
            guna2Panel3.Name = "guna2Panel3";
            guna2Panel3.ShadowDecoration.CustomizableEdges = customizableEdges82;
            guna2Panel3.Size = new Size(1220, 193);
            guna2Panel3.TabIndex = 4;
            // 
            // btnChangeAccount1
            // 
            btnChangeAccount1.BorderRadius = 8;
            btnChangeAccount1.CustomizableEdges = customizableEdges78;
            btnChangeAccount1.DisabledState.BorderColor = Color.DarkGray;
            btnChangeAccount1.DisabledState.CustomBorderColor = Color.DarkGray;
            btnChangeAccount1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnChangeAccount1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnChangeAccount1.FillColor = Color.FromArgb(186, 67, 43);
            btnChangeAccount1.Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            btnChangeAccount1.ForeColor = Color.FromArgb(225, 228, 231);
            btnChangeAccount1.HoverState.FillColor = Color.FromArgb(207, 75, 50);
            btnChangeAccount1.Location = new Point(142, 124);
            btnChangeAccount1.Margin = new Padding(1);
            btnChangeAccount1.Name = "btnChangeAccount1";
            btnChangeAccount1.PressedColor = Color.White;
            btnChangeAccount1.ShadowDecoration.CustomizableEdges = customizableEdges79;
            btnChangeAccount1.Size = new Size(149, 30);
            btnChangeAccount1.TabIndex = 16;
            btnChangeAccount1.Text = "Сменить аккаунт";
            btnChangeAccount1.Click += btnChangeAccount_Click;
            // 
            // textEmail1
            // 
            textEmail1.AutoSize = true;
            textEmail1.Font = new Font("Roboto", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            textEmail1.ForeColor = Color.Gray;
            textEmail1.Location = new Point(141, 96);
            textEmail1.Name = "textEmail1";
            textEmail1.Size = new Size(38, 15);
            textEmail1.TabIndex = 5;
            textEmail1.Text = "Email";
            textEmail1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // guna2CirclePictureBox2
            // 
            guna2CirclePictureBox2.BackColor = Color.Transparent;
            guna2CirclePictureBox2.Image = (Image)resources.GetObject("guna2CirclePictureBox2.Image");
            guna2CirclePictureBox2.ImageRotate = 0F;
            guna2CirclePictureBox2.InitialImage = null;
            guna2CirclePictureBox2.Location = new Point(19, 54);
            guna2CirclePictureBox2.Name = "guna2CirclePictureBox2";
            guna2CirclePictureBox2.ShadowDecoration.CustomizableEdges = customizableEdges80;
            guna2CirclePictureBox2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox2.Size = new Size(100, 100);
            guna2CirclePictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            guna2CirclePictureBox2.TabIndex = 3;
            guna2CirclePictureBox2.TabStop = false;
            guna2CirclePictureBox2.UseTransparentBackground = true;
            // 
            // textUsername1
            // 
            textUsername1.AutoSize = true;
            textUsername1.Font = new Font("Roboto", 18F, FontStyle.Regular, GraphicsUnit.Point);
            textUsername1.ForeColor = Color.White;
            textUsername1.Location = new Point(138, 66);
            textUsername1.Name = "textUsername1";
            textUsername1.Size = new Size(122, 29);
            textUsername1.TabIndex = 4;
            textUsername1.Text = "Username";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Roboto", 9F, FontStyle.Italic, GraphicsUnit.Point);
            label8.ForeColor = Color.Gray;
            label8.Location = new Point(10, 9);
            label8.Name = "label8";
            label8.Size = new Size(119, 14);
            label8.TabIndex = 2;
            label8.Text = "Вы вошли в аккаунт";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // dragMainWindow
            // 
            dragMainWindow.DockIndicatorTransparencyValue = 0.6D;
            dragMainWindow.TargetControl = head;
            dragMainWindow.TransparentWhileDrag = false;
            // 
            // GroupSelectionScenario
            // 
            AutoScaleDimensions = new SizeF(8F, 18F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(22, 23, 27);
            ClientSize = new Size(1264, 678);
            Controls.Add(TabControl);
            Controls.Add(head);
            DoubleBuffered = true;
            Font = new Font("Roboto", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "GroupSelectionScenario";
            Opacity = 0D;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Group_Selection_Scenario";
            head.ResumeLayout(false);
            TabControl.ResumeLayout(false);
            pgSelect.ResumeLayout(false);
            pgSelect.PerformLayout();
            pgInviteCode.ResumeLayout(false);
            pgInviteCode.PerformLayout();
            guna2Panel2.ResumeLayout(false);
            guna2Panel2.PerformLayout();
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            teacherReg.ResumeLayout(false);
            guna2Panel4.ResumeLayout(false);
            guna2Panel4.PerformLayout();
            guna2Panel3.ResumeLayout(false);
            guna2Panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm border;
        private Guna.UI2.WinForms.Guna2GradientPanel head;
        private Guna.UI2.WinForms.Guna2CircleButton btnMinimize;
        private Guna.UI2.WinForms.Guna2CircleButton btnExit;
        private Guna.UI2.WinForms.Guna2TabControl TabControl;
        private TabPage pgSelect;
        private TabPage pgInviteCode;
        private Label textPrompt;
        private Label textChoice;
        private Guna.UI2.WinForms.Guna2TileButton btnGroups;
        private Guna.UI2.WinForms.Guna2TileButton btnIndependent;
        private Guna.UI2.WinForms.Guna2DragControl dragMainWindow;
        private Guna.UI2.WinForms.Guna2TextBox inputInviteCode1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Label label;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Label textUsername;
        private Label textEmail;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Label label4;
        private Guna.UI2.WinForms.Guna2Button btnChangeAccount;
        private Label label2;
        private Label label3;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Label label5;
        private Label label6;
        private Guna.UI2.WinForms.Guna2Button btnCancel1;
        private Guna.UI2.WinForms.Guna2Button btnEnterStudent;
        private Label btnTeacher;
        private TabPage teacherReg;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2TextBox inputGroupName;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2Button btnChangeAccount1;
        private Label textEmail1;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox2;
        private Label textUsername1;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Guna.UI2.WinForms.Guna2ImageButton btnGenerateCode;
        private Guna.UI2.WinForms.Guna2TextBox inputInviteCode2;
        private Label label12;
        private Label label13;
        private Guna.UI2.WinForms.Guna2Button btnCancel2;
        private Guna.UI2.WinForms.Guna2Button btnSkip;
        private Guna.UI2.WinForms.Guna2Button btnEnterTeacher;
    }
}