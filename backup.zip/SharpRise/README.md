**SharpRise** is a desktop application for learning the C# programming language. 

**Description:**

**Want to learn C# but don’t know where to start?**
SharpRise offers a fast and effective way to master the language. Based on materials from [Metanit](https://metanit.com/sharp/) and enhanced with a variety of tasks of different difficulty levels, it will help you become a confident developer step by step.

**Are you a teacher looking to simplify the process of teaching and working?**
Create study groups, invite students, prepare materials, and take full advantage of tool for maximum convenience. Teaching has never been easier!


*The application is developed on WinForms technology for coursework and will not be supported further.*

Contact: [@sskkyywalker](https://t.me/sskkywalker)
