﻿Random _random = new Random();
const string Letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const string Numbers = "0123456789";

var letterPart = new string(Enumerable.Repeat(Letters, 4)
   .Select(s => s[_random.Next(s.Length)])
   .ToArray());

var numberPart = new string(Enumerable.Repeat(Numbers, 4)
    .Select(s => s[_random.Next(s.Length)])
    .ToArray());

Console.WriteLine($"{letterPart}-{numberPart}");